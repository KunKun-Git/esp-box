/*
 * SPDX-FileCopyrightText: 2015-2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 */
#ifndef _APP_SNTP_H_
#define _APP_SNTP_H_


#ifdef __cplusplus
extern "C" {
#endif

void app_sntp_init(void);

#ifdef __cplusplus
}
#endif

#endif

